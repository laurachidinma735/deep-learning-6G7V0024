An endoscopic view showing a raised, pinkish-red mucosal surface with a textured, reticular pattern and bright fluid reflections. A large dark region obscures the lower-left corner of the frame.
