An endoscopic view shows pink, folded mucosal tissue with bright fluid reflections and a raised, textured, reddish area in the upper right. White text overlays are visible in the upper left corner.
