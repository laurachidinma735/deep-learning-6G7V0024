An endoscopic view shows pink mucosal tissue with a central raised, rounded structure and bright fluid reflections. A green rectangular overlay partially covers the lower-left corner of the image.
