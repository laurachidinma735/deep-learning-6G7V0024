An endoscopic view shows a tubular lumen with smooth, pinkish-brown mucosal walls and bright fluid reflections. A green rectangular overlay partially covers the lower-left corner of the image.
